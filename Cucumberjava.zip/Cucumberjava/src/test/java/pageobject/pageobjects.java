package pageobject;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

public class pageobjects {

	public WebDriver driver;
	
	public pageobjects(WebDriver driver)
	{
		this.driver=driver;
	
	}
	By creatreNewAccount = By.xpath("//a[@id='u_0_2_z3']");
	By Fname = By.xpath("//input[@name='firstname']");
	By Lname = By.xpath("//input[@name='lastname']");
	By Mobilenum = By.xpath("//input[@name='reg_email__']");
	

public WebElement creatreNewAccount()
{
	return driver.findElement(creatreNewAccount);
}
public WebElement Fname()
{
	return driver.findElement(Fname);
}
public WebElement Lname()
{
	return driver.findElement(Lname);
}
public WebElement Mobilenum()
{
	return driver.findElement(Mobilenum);
}
}
