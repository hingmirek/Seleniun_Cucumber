package Stepdefination;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import Baseclass.Base;
import cucumber.annotation.en.*;

import pageobject.pageobjects;

public class Stepsdefination extends Base {
	public WebDriver driver;
	
	public pageobjects pt;
	    @Given("^user launch the browser$")
	    public void user_launch_the_browser() throws Throwable {
	    driver = new ChromeDriver();
	      pt = new pageobjects(driver);
	    
	    }
	    @And("^user enter the url\"([^\"]*)\" $")
	    public void user_enter_the_urlsomething(String strArg1) throws Throwable {
	    	pt.driver.get(strArg1);
	    }


	    @Then("^user click on create new account button$")
	    public void user_click_on_create_new_account_button() throws Throwable {
	       pt.creatreNewAccount().click();
	    }

	  
	    @And("^user enter fname\"([^\"]*)\" and lname\"([^\"]*)\"$")
	    public void user_enter_fnamesomething_and_lnamesomething(String strArg1, String strArg2) throws Throwable {
	       pt.Fname().sendKeys(strArg1);
	       pt.Lname().sendKeys(strArg2);
	    }

	    @And("^user enter mobile number\"([^\"]*)\"$")
	    public void user_enter_mobile_numbersomething(String strArg1) throws Throwable {
	        pt.Mobilenum().sendKeys(strArg1);
	    }
	
	}
