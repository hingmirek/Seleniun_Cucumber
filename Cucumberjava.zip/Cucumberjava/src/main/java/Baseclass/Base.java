package Baseclass;

import java.io.FileInputStream;
import java.io.IOException;
import java.util.Properties;
import java.util.concurrent.TimeUnit;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;


public class Base {
	public static WebDriver driver;
	public Properties prop;
	@SuppressWarnings("deprecation")
	public WebDriver initializeDriver() throws IOException
	{
	
prop = new Properties();

FileInputStream fis = new FileInputStream("C:\\Users\\hingm\\eclipse-workspace\\E2E\\src\\main\\java\\E2EProject\\E2E\\data.properties");
prop.load(fis);
String browsename = prop.getProperty("Browser");
System.out.println(browsename);
if(browsename.equals("chrome"))
{
	System.setProperty("webdriver.chrome.driver","C:\\Seleniumtest\\chromedriver_win32 (2)\\chromedriver.exe");
	
	//ChromeOptions options = new ChromeOptions();
	//options.addArguments("headless");
	driver = new ChromeDriver() ;
}
else
{
	if(browsename.equals("firebox"))
	{
		//setProperty for firebox
			
	}
}
driver.manage().timeouts().implicitlyWait(2, TimeUnit.SECONDS);

 return driver;

	}

}
	
	


