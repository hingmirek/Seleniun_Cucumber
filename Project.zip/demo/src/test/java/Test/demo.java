package Test;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.SearchContext;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

//Check that all menu links in the top navigation work (Our Products to Get in Touch)
public class demo {

	static int linkCount = 0;
	public static void main(String[] args) throws InterruptedException 
	{

		System.setProperty("webdriver.chrome.driver","C:\\Users\\hingm\\eclipse-workspace\\demo\\src\\test\\resources\\driver\\chromedriver.exe");

		WebDriver driver = new ChromeDriver();

		driver.get("https://www.growthengineering.co.uk/");
		driver.manage().window().maximize();
	    driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
	    
		for (WebElement links: driver.findElements(By.tagName("a"))) {
			System.out.println(links.getText());

			linkCount++;
		}
		System.out.println("Total Links on Page : " + linkCount);
		{

			//Check that form validation works on the contact page
			driver.findElement(By.id("contact-button")).click();
			System.out.println("Conatct page title is :" +driver.getTitle());
			driver.findElement(By.id("full_name-63c6168e-e30a-4c79-ab68-77cedae08dfe")).isEnabled();
			
			WebElement dropdown = driver.findElement(By.xpath("//*[@id=\"country_-63c6168e-e30a-4c79-ab68-77cedae08dfe\"]")); 

			// Validation of Dropdown
			   if(dropdown.isEnabled() && dropdown.isDisplayed()) 
			   { 
			      System.out.println("Dropdown is visible"); 
			   } 
			  else { 
			      System.out.println("Dropdown is not visible"); 
			  } 
			Thread.sleep(2000);
			driver.quit();
		}
	}
}







