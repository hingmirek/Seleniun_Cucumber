package StepDefination;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class Stepdefination {
	static int linkCount = 0;
	WebDriver driver = null;
	@Given("user is open Browser")
	public void user_is_open_browser() {
		System.setProperty("webdriver.chrome.driver","C:\\Users\\hingm\\eclipse-workspace\\demo\\src\\test\\resources\\driver\\chromedriver.exe");
		driver = new ChromeDriver();
	}

	@When("enter URL")
	public void enter_url() {
		driver.get("https://www.growthengineering.co.uk/");
		// driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
	}

	@And("user hit enter")
	public void user_hit_enter() {
	 System.out.println("user hit the URL");

	}
	@Then("user is on home page")
	public void user_is_on_home_pager() {
	 System.out.println(" driver.getTitle();");
	}

	@Given("user click on contact link	static int linkCount = {int};")
	public void user_click_on_contact_link_static_int_link_count(Integer int1) {
		
		driver.findElement(By.id("contact-button")).click();
		System.out.println("Conatct page title is :" +driver.getTitle());
		driver.findElement(By.id("full_name-63c6168e-e30a-4c79-ab68-77cedae08dfe")).isEnabled();
		
	}

	@Then("user validate fields")
	public void user_validate_fields() {
		
		WebElement dropdown = driver.findElement(By.xpath("//*[@id=\"country_-63c6168e-e30a-4c79-ab68-77cedae08dfe\"]")); 

		// Validation of Dropdown
		   if(dropdown.isEnabled() && dropdown.isDisplayed()) 
		   { 
		      System.out.println("Dropdown is visible"); 
		   } 
		  else { 
		      System.out.println("Dropdown is not visible"); 
		  } 
		
	}
	@Then("user check all links on page")
	
	public void user_check_all_links_on_page() {
		
		
		for (WebElement links: driver.findElements(By.tagName("a"))) {
			
			System.out.println(links.getText());

			linkCount++;
			{
		System.out.println("Total Links on Page : " + linkCount);
		}	
			
			
}
	}
}
	

	
